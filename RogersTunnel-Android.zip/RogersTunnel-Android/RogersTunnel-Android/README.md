# Roger'sTunnel — Android Studio Projesi

Görseldeki koyu mor temalı tünel istemcisinin **Kotlin + Jetpack Compose** ile geliştirilmiş daha gelişmiş Android proje iskeleti.

## Öne Çıkan Özellikler
- **Çoklu Protokol Desteği:** VLESS, VMess, Trojan ve Shadowsocks (`ConfigUriParser.kt` ile URI ayrıştırma).
- **Gelişmiş SNI & DPI Koruması:** Genel SNI Override, TLS Fragment ve Mux ayarları.
- **Gerçek `VpnService` Altyapısı:** Ön plan servisi (`RogersTunnelVpnService.kt`), özel DNS yönlendirme ve **Split Tunneling** (`addDisallowedApplication`).
- **Canlı İzleme:** Gerçek zamanlı TCP Ping testi, indirme/yükleme hız sayacı ve çekirdek log penceresi.
- **Otomatik APK Derleme (GitHub Actions):** `.github/workflows/build-apk.yml` sayesinde projeyi GitHub'a yüklediğinizde otomatik `.apk` çıktısı alabilirsiniz.

## APK Nasıl Derlenir?
1. Bu klasörü **Android Studio** ile açın (Gradle otomatik senkronize olur).
2. Gerçek tünel trafiği için `app/build.gradle.kts` içindeki `AndroidLibXrayLite` satırını etkinleştirip `RogersTunnelVpnService.kt` içindeki TUN dosya tanımlayıcısını (`tunInterface.fd`) çekirdeğe bağlayın.
3. Menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin veya terminalde `./gradlew assembleDebug` çalıştırın.
