package com.rogerstunnel.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDeep = Color(0xFF0D0716)
val CardSurface = Color(0xFF21123B)
val PrimaryViolet = Color(0xFF7C3AED)
val AccentCyan = Color(0xFF38BDF8)
val AccentEmerald = Color(0xFF34D399)
val TextPrimary = Color(0xFFF3F0FF)
val TextMuted = Color(0xFFB8A9D9)

private val DarkScheme = darkColorScheme(
    primary = PrimaryViolet,
    secondary = AccentCyan,
    background = BgDeep,
    surface = CardSurface,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun RogersTunnelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkScheme,
        content = content
    )
}
