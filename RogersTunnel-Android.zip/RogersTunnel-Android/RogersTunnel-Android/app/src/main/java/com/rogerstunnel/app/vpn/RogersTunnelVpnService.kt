package com.rogerstunnel.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class RogersTunnelVpnService : VpnService() {

    private var tunInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val serverName = intent.getStringExtra(EXTRA_SERVER_NAME) ?: "Roger'sTunnel"
                val dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1"
                val bypassed = intent.getStringArrayListExtra(EXTRA_BYPASSED_APPS) ?: arrayListOf()
                startForegroundNotification(serverName)
                establishTun(dns, bypassed)
            }
        }
        return START_STICKY
    }

    private fun establishTun(dnsServer: String, bypassedPackages: List<String>) {
        tunInterface?.close()
        val builder = Builder()
            .setSession("Roger'sTunnel")
            .setMtu(1500)
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(dnsServer)

        bypassedPackages.forEach { pkg ->
            runCatching { builder.addDisallowedApplication(pkg) }
        }

        tunInterface = builder.establish()
        // TODO: LibXray / sing-box çekirdeğini tunInterface.fd ile başlatın
    }

    private fun stopTunnel() {
        runCatching { tunInterface?.close() }
        tunInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun startForegroundNotification(serverName: String) {
        val channelId = "rogerstunnel_vpn"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Roger'sTunnel VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Roger'sTunnel Aktif")
            .setContentText("Bağlı: $serverName")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
        startForeground(101, notification)
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.rogerstunnel.START"
        const val ACTION_STOP = "com.rogerstunnel.STOP"
        const val EXTRA_SERVER_NAME = "server_name"
        const val EXTRA_DNS = "dns_server"
        const val EXTRA_BYPASSED_APPS = "bypassed_apps"
    }
}
