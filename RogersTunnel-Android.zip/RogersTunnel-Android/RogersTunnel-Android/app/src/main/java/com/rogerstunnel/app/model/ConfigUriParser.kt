package com.rogerstunnel.app.model

import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.net.URLDecoder

object ConfigUriParser {
    fun parse(rawUri: String): Result<TunnelConfig> = runCatching {
        val trimmed = rawUri.trim()
        when {
            trimmed.startsWith("vless://", ignoreCase = true) -> parseStandardUri(trimmed, TunnelProtocol.VLESS)
            trimmed.startsWith("trojan://", ignoreCase = true) -> parseStandardUri(trimmed, TunnelProtocol.TROJAN)
            trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
            trimmed.startsWith("ss://", ignoreCase = true) -> parseStandardUri(trimmed, TunnelProtocol.SHADOWSOCKS)
            else -> error("Desteklenmeyen URI protokolü")
        }
    }

    private fun parseStandardUri(raw: String, protocol: TunnelProtocol): TunnelConfig {
        val normalized = raw.replaceFirst(Regex("^[a-zA-Z]+://"), "https://")
        val uri = Uri.parse(normalized)
        val host = uri.host ?: error("Sunucu adresi bulunamadı")
        val port = if (uri.port > 0) uri.port else 443
        val userInfo = uri.userInfo ?: ""
        val sni = uri.getQueryParameter("sni") ?: uri.getQueryParameter("host") ?: host
        val transport = uri.getQueryParameter("type") ?: "ws"
        val remark = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") }?.ifBlank { null }
            ?: "${protocol.label} $host"

        return TunnelConfig(
            name = remark,
            protocol = protocol,
            host = host,
            port = port,
            sni = sni,
            transport = transport,
            uuidOrPassword = userInfo
        )
    }

    private fun parseVmess(raw: String): TunnelConfig {
        val encoded = raw.removePrefix("vmess://").trim()
        val jsonStr = String(Base64.decode(encoded, Base64.DEFAULT))
        val obj = JSONObject(jsonStr)
        return TunnelConfig(
            name = obj.optString("ps", "VMess Sunucu"),
            protocol = TunnelProtocol.VMESS,
            host = obj.getString("add"),
            port = obj.optInt("port", 443),
            sni = obj.optString("sni").ifBlank { obj.optString("host", obj.getString("add")) },
            transport = obj.optString("net", "ws"),
            uuidOrPassword = obj.getString("id")
        )
    }
}
