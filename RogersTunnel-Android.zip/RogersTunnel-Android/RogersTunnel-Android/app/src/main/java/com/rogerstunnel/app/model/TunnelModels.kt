package com.rogerstunnel.app.model

import java.util.UUID

enum class TunnelProtocol(val label: String, val badge: String) {
    VLESS("VLESS", "VL"),
    VMESS("VMess", "VM"),
    TROJAN("Trojan", "TR"),
    SHADOWSOCKS("Shadowsocks", "SS")
}

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

data class TunnelConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: TunnelProtocol,
    val host: String,
    val port: Int,
    val sni: String,
    val transport: String = "ws",
    val uuidOrPassword: String,
    val pingMs: Int? = null
)

data class TunnelSettings(
    val globalSniOverride: String = "",
    val tlsFragmentEnabled: Boolean = true,
    val muxEnabled: Boolean = false,
    val killSwitchEnabled: Boolean = true,
    val autoReconnect: Boolean = true,
    val dnsServer: String = "1.1.1.1",
    val bypassedPackages: Set<String> = setOf("com.garanti.cepsubesi")
)

data class TrafficStats(
    val downloadMbps: Float = 0f,
    val uploadMbps: Float = 0f,
    val totalMegabytes: Double = 0.0,
    val elapsedSeconds: Long = 0L
)
