package com.rogerstunnel.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rogerstunnel.app.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class TunnelViewModel : ViewModel() {

    private val _configs = MutableStateFlow(
        listOf(
            TunnelConfig("1", "Chatgpt -TR-VIP", TunnelProtocol.VLESS, "45.198.68.135", 443, "chatgpt.com", "ws", "8f3a1c92-44b1-4e7a", 42),
            TunnelConfig("2", "Almanya Frankfurt #2", TunnelProtocol.VLESS, "185.214.12.90", 443, "cdn.cloudflare.net", "grpc", "a21c9f01-77d3-411a", 58),
            TunnelConfig("3", "Hollanda Amsterdam", TunnelProtocol.TROJAN, "91.132.144.21", 443, "m.youtube.com", "tcp", "trj-pass-rogers", 64)
        )
    )
    val configs: StateFlow<List<TunnelConfig>> = _configs.asStateFlow()

    private val _activeConfigId = MutableStateFlow("1")
    val activeConfigId: StateFlow<String> = _activeConfigId.asStateFlow()

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _settings = MutableStateFlow(TunnelSettings())
    val settings: StateFlow<TunnelSettings> = _settings.asStateFlow()

    private val _stats = MutableStateFlow(TrafficStats())
    val stats: StateFlow<TrafficStats> = _stats.asStateFlow()

    private val _logs = MutableStateFlow(listOf("[INFO] Roger'sTunnel başlatıldı."))
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private var timerJob: Job? = null

    fun selectConfig(id: String) {
        _activeConfigId.value = id
        addLog("[INFO] Aktif config seçildi: ${configs.value.find { it.id == id }?.name}")
    }

    fun addOrImportConfig(rawUriOrConfig: TunnelConfig) {
        _configs.update { listOf(rawUriOrConfig) + it }
        _activeConfigId.value = rawUriOrConfig.id
        addLog("[OK] Yeni config eklendi: ${rawUriOrConfig.name}")
    }

    fun deleteConfig(id: String) {
        if (_configs.value.size <= 1) return
        _configs.update { list -> list.filterNot { it.id == id } }
        if (_activeConfigId.value == id) {
            _activeConfigId.value = _configs.value.first().id
        }
    }

    fun pingConfig(id: String) {
        val cfg = _configs.value.find { it.id == id } ?: return
        viewModelScope.launch {
            val ms = measureTcpPing(cfg.host, cfg.port)
            _configs.update { list -> list.map { if (it.id == id) it.copy(pingMs = ms) else it } }
            addLog("[PING] ${cfg.name}: ${ms?.let { "$it ms" } ?: "Zaman aşımı"}")
        }
    }

    fun toggleConnection(onStartVpn: (TunnelConfig, TunnelSettings) -> Unit, onStopVpn: () -> Unit) {
        when (_connectionState.value) {
            ConnectionState.DISCONNECTED -> {
                val cfg = _configs.value.find { it.id == _activeConfigId.value } ?: return
                _connectionState.value = ConnectionState.CONNECTING
                addLog("[INFO] ${cfg.name} (${cfg.protocol.label}) için tünel kuruluyor...")
                viewModelScope.launch {
                    delay(800)
                    onStartVpn(cfg, _settings.value)
                    _connectionState.value = ConnectionState.CONNECTED
                    addLog("[OK] Tünel aktif! SNI: ${_settings.value.globalSniOverride.ifBlank { cfg.sni }}")
                    startTrafficTimer()
                }
            }
            ConnectionState.CONNECTED, ConnectionState.CONNECTING -> {
                timerJob?.cancel()
                onStopVpn()
                _connectionState.value = ConnectionState.DISCONNECTED
                _stats.value = TrafficStats()
                addLog("[WARN] Bağlantı sonlandırıldı.")
            }
        }
    }

    fun updateSettings(transform: (TunnelSettings) -> TunnelSettings) {
        _settings.update(transform)
    }

    private fun startTrafficTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _stats.update { cur ->
                    val down = (10..38).random().toFloat()
                    val up = (2..12).random().toFloat()
                    cur.copy(
                        downloadMbps = down,
                        uploadMbps = up,
                        totalMegabytes = cur.totalMegabytes + (down + up) / 8.0,
                        elapsedSeconds = cur.elapsedSeconds + 1
                    )
                }
            }
        }
    }

    private suspend fun measureTcpPing(host: String, port: Int): Int? = withContext(Dispatchers.IO) {
        runCatching {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 2500)
            }
            (System.currentTimeMillis() - start).toInt()
        }.getOrNull()
    }

    private fun addLog(entry: String) {
        _logs.update { (it + entry).takeLast(100) }
    }
}
