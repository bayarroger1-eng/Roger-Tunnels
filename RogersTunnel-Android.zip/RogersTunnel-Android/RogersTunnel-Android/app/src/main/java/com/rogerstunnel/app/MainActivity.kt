package com.rogerstunnel.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rogerstunnel.app.model.ConfigUriParser
import com.rogerstunnel.app.model.TunnelConfig
import com.rogerstunnel.app.model.TunnelSettings
import com.rogerstunnel.app.ui.screens.ConnectionScreen
import com.rogerstunnel.app.ui.theme.*
import com.rogerstunnel.app.viewmodel.TunnelViewModel
import com.rogerstunnel.app.vpn.RogersTunnelVpnService

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RogersTunnelTheme {
                RogersTunnelRoot()
            }
        }
    }
}

@Composable
fun RogersTunnelRoot(vm: TunnelViewModel = viewModel()) {
    val context = LocalContext.current
    val configs by vm.configs.collectAsState()
    val activeId by vm.activeConfigId.collectAsState()
    val connState by vm.connectionState.collectAsState()
    val settings by vm.settings.collectAsState()
    val stats by vm.stats.collectAsState()
    val logs by vm.logs.collectAsState()

    var currentTab by remember { mutableIntStateOf(0) }
    var showLogs by remember { mutableStateOf(false) }
    var showUriDialog by remember { mutableStateOf(false) }
    var uriInput by remember { mutableStateOf("") }

    var pendingStart by remember { mutableStateOf<Pair<TunnelConfig, TunnelSettings>?>(null) }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingStart?.let { (cfg, st) ->
                startVpnService(context, cfg, st)
                pendingStart = null
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDeep)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Üst Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Shield, contentDescription = null, tint = AccentCyan)
                    }
                    Text("Roger'sTunnel", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                IconButton(onClick = { showLogs = true }) {
                    Icon(Icons.Rounded.Article, contentDescription = "Loglar", tint = TextPrimary)
                }
            }

            when (currentTab) {
                0 -> ConnectionScreen(
                    connectionState = connState,
                    activeConfig = configs.find { it.id == activeId },
                    stats = stats,
                    sniOverride = settings.globalSniOverride,
                    onToggleConnection = {
                        vm.toggleConnection(
                            onStartVpn = { cfg, st ->
                                val prep = VpnService.prepare(context)
                                if (prep != null) {
                                    pendingStart = cfg to st
                                    vpnPermissionLauncher.launch(prep)
                                } else {
                                    startVpnService(context, cfg, st)
                                }
                            },
                            onStopVpn = {
                                val stopIntent = Intent(context, RogersTunnelVpnService::class.java).apply {
                                    action = RogersTunnelVpnService.ACTION_STOP
                                }
                                context.startService(stopIntent)
                            }
                        )
                    },
                    onPingClick = { vm.pingConfig(activeId) },
                    onOpenConfigs = { currentTab = 1 }
                )

                1 -> Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Configler", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Button(onClick = { showUriDialog = true }) {
                            Text("+ URI Ekle")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(configs, key = { it.id }) { cfg ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (cfg.id == activeId) PrimaryViolet.copy(alpha = 0.25f) else CardSurface)
                                    .clickable { vm.selectConfig(cfg.id) }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${cfg.protocol.label} • ${cfg.name}", color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text("${cfg.host}:${cfg.port} • SNI: ${cfg.sni}", color = TextMuted, fontSize = 12.sp)
                                }
                                IconButton(onClick = { vm.deleteConfig(cfg.id) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Sil", tint = Color(0xFFFCA5A5))
                                }
                            }
                        }
                    }
                }

                2 -> Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Gelişmiş Ayarlar", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    OutlinedTextField(
                        value = settings.globalSniOverride,
                        onValueChange = { v -> vm.updateSettings { it.copy(globalSniOverride = v) } },
                        label = { Text("Genel SNI Override") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    SettingSwitchRow("TLS Fragment (DPI Koruması)", settings.tlsFragmentEnabled) { checked ->
                        vm.updateSettings { it.copy(tlsFragmentEnabled = checked) }
                    }
                    SettingSwitchRow("Kill Switch", settings.killSwitchEnabled) { checked ->
                        vm.updateSettings { it.copy(killSwitchEnabled = checked) }
                    }
                    SettingSwitchRow("Otomatik Yeniden Bağlan", settings.autoReconnect) { checked ->
                        vm.updateSettings { it.copy(autoReconnect = checked) }
                    }
                }
            }
        }

        // Alt Menü
        NavigationBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
                .clip(RoundedCornerShape(32.dp)),
            containerColor = CardSurface
        ) {
            NavigationBarItem(
                selected = currentTab == 0,
                onClick = { currentTab = 0 },
                icon = { Icon(Icons.Rounded.Shield, null) },
                label = { Text("Bağlantı") }
            )
            NavigationBarItem(
                selected = currentTab == 1,
                onClick = { currentTab = 1 },
                icon = { Icon(Icons.Rounded.Public, null) },
                label = { Text("Configler") }
            )
            NavigationBarItem(
                selected = currentTab == 2,
                onClick = { currentTab = 2 },
                icon = { Icon(Icons.Rounded.Tune, null) },
                label = { Text("Ayarlar") }
            )
        }
    }

    if (showUriDialog) {
        AlertDialog(
            onDismissRequest = { showUriDialog = false },
            title = { Text("URI İle Config Ekle") },
            text = {
                OutlinedTextField(
                    value = uriInput,
                    onValueChange = { uriInput = it },
                    placeholder = { Text("vless://... veya trojan://...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    ConfigUriParser.parse(uriInput).onSuccess {
                        vm.addOrImportConfig(it)
                        uriInput = ""
                        showUriDialog = false
                    }
                }) { Text("Ekle") }
            },
            dismissButton = {
                TextButton(onClick = { showUriDialog = false }) { Text("İptal") }
            }
        )
    }

    if (showLogs) {
        AlertDialog(
            onDismissRequest = { showLogs = false },
            title = { Text("Çekirdek Logları") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 280.dp)) {
                    items(logs) { line ->
                        Text(line, fontSize = 11.sp, color = TextMuted)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLogs = false }) { Text("Kapat") }
            }
        )
    }
}

@Composable
private fun SettingSwitchRow(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun startVpnService(context: android.content.Context, cfg: TunnelConfig, settings: TunnelSettings) {
    val intent = Intent(context, RogersTunnelVpnService::class.java).apply {
        action = RogersTunnelVpnService.ACTION_START
        putExtra(RogersTunnelVpnService.EXTRA_SERVER_NAME, cfg.name)
        putExtra(RogersTunnelVpnService.EXTRA_DNS, settings.dnsServer)
        putStringArrayListExtra(RogersTunnelVpnService.EXTRA_BYPASSED_APPS, ArrayList(settings.bypassedPackages))
    }
    context.startForegroundService(intent)
}
