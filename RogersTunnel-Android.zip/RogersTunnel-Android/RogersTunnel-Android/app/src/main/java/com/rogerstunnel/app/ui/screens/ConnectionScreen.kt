package com.rogerstunnel.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rogerstunnel.app.model.*
import com.rogerstunnel.app.ui.theme.*

@Composable
fun ConnectionScreen(
    connectionState: ConnectionState,
    activeConfig: TunnelConfig?,
    stats: TrafficStats,
    sniOverride: String,
    onToggleConnection: () -> Unit,
    onPingClick: () -> Unit,
    onOpenConfigs: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(Modifier.height(8.dp))

        // Durum Başlığı
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val (dotColor, titleText, subText) = when (connectionState) {
                ConnectionState.DISCONNECTED -> Triple(Color(0xFF94A3B8), "Bağlı değil", "Hazır • bağlanmak için dokun")
                ConnectionState.CONNECTING -> Triple(Color(0xFFFBBF24), "Bağlanıyor...", "TLS + SNI el sıkışması yapılıyor")
                ConnectionState.CONNECTED -> Triple(AccentEmerald, "Bağlı", "${activeConfig?.name ?: ""} • Tünel Aktif")
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(dotColor))
                Text(titleText, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
            }
            Spacer(Modifier.height(4.dp))
            Text(subText, fontSize = 13.sp, color = TextMuted)
        }

        // Merkezi Güç Butonu
        Box(
            modifier = Modifier
                .size(196.dp)
                .clip(CircleShape)
                .border(2.dp, PrimaryViolet.copy(alpha = 0.45f), CircleShape)
                .padding(14.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            if (connectionState == ConnectionState.CONNECTED) PrimaryViolet else Color(0xFF4C1D95),
                            Color(0xFF260F52)
                        )
                    )
                )
                .clickable { onToggleConnection() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.PowerSettingsNew,
                    contentDescription = "Bağlan",
                    tint = Color.White,
                    modifier = Modifier.size(52.dp)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (connectionState == ConnectionState.CONNECTED) "KES" else "BAĞLAN",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }

        // Canlı Hız Kartları
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("İndirme", "${stats.downloadMbps.toInt()} Mbps", AccentEmerald, Modifier.weight(1f))
            StatCard("Yükleme", "${stats.uploadMbps.toInt()} Mbps", AccentCyan, Modifier.weight(1f))
            StatCard("Toplam", String.format("%.1f MB", stats.totalMegabytes), TextPrimary, Modifier.weight(1f))
        }

        // Aktif Config Kartı
        activeConfig?.let { cfg ->
            val effectiveSni = sniOverride.ifBlank { cfg.sni }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CardSurface)
                    .border(1.dp, PrimaryViolet.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                    .clickable { onOpenConfigs() }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(PrimaryViolet.copy(alpha = 0.35f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(cfg.protocol.badge, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("SNI: $effectiveSni", color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Text(cfg.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                        Text("${cfg.protocol.label} • ${cfg.host}:${cfg.port}", color = TextMuted, fontSize = 11.sp)
                    }
                }
                FilledTonalButton(
                    onClick = onPingClick,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(cfg.pingMs?.let { "$it ms" } ?: "PING", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(84.dp))
    }
}

@Composable
private fun StatCard(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, fontSize = 11.sp, color = TextMuted)
        Spacer(Modifier.height(2.dp))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
